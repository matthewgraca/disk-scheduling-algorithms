How to run:

java -jar executables/filename.jar

Where "filename" is the name of any of the three files in the executables folder.
